import sqlite3
class ChatAppOrm:
    def __init__(self):#You don't need to pass something into the self. 
        self.conn = None  # will store the DB connection
        self.cursor = None  # will store the DB connection cursor
    def create_tables(self):
        create_table_query = '''
        CREATE TABLE IF NOT EXISTS users_table (
            ID INTEGER PRIMARY KEY AUTOINCREMENT,
            Name TEXT,
            Password TEXT,
            Bio TEXT,
            CreatedDate TEXT
        );
        '''
        self.open_DB()
        self.cursor.execute(create_table_query)
        self.commit()
        self.close_DB()
    def open_DB(self):
        """
        will open DB file and put value in:
        self.conn (need DB file name)
        and self.cursor
        """
        self.conn = sqlite3.connect('./AppChatDB.db')
        self.cursor = self.conn.cursor()
    def get_all_users(self):
        self.open_DB()
        users = []
        sql = "SELECT * FROM users_table"
        res = self.cursor.execute(sql)
        for row in res:
            user = User(row[1], row[2], row[3], row[4])
            users.append(user)
        self.close_DB()
        return users
    def update_user(self,data):
        current_name, name,password,bio,createdDate = data
        try:
            all_users = self.get_all_users()
            self.open_DB()
            found_user = None
            for user in all_users:
                if(user.name == current_name):
                    found_user = name
                    self.cursor.execute("UPDATE users_table set Name=?, password=?, Bio=?, CreatedDate=? WHERE Name=?", (name,password,bio,createdDate,current_name))
                    self.commit()
            if(found_user == None):
                return False
        except Exception as e:
            print(f"Exception : {e} ")
            return False
        finally:
            self.close_DB()
    def insert_user(self,data):
        try:
            name,password,bio,createdDate = data
            users = self.get_all_users()
            self.open_DB()
            for user in users:
                if(user.name == name):
                    return False,"User already exists"
            self.cursor.execute("INSERT INTO users_table (Name, Password, Bio, CreatedDate) VALUES (?, ?, ?, ?)",(name,password,bio,createdDate))
            self.commit()
            return True
        except Exception as e:
            return False,str(e)
        finally:
            self.close_DB()
    def delete_user(self,name):
        try:
            self.open_DB()
            sql = "DELETE FROM users_table WHERE Name=?"
            self.cursor.execute(sql, (name,))
            self.commit()
        except Exception as e:
            print(f"Exception: {e}")
        finally:
            self.close_DB()
    def close_DB(self):
        self.conn.close()
    def commit(self):
        self.conn.commit()

class User:
    def __init__(self,name,password,bio,createdDate):
        self.name = name
        self.password = password
        self.bio = bio
        self.createdDate = createdDate
    def __str__(self):
        return f"Name : {self.name}\nPassword : {self.password}\nBio : {self.bio}\ncreatedDate : {self.createdDate}\n"
    

if __name__ == "__main__":
    user1 = User("Guy","GGG123", "Hello World","10/10/2005")
    instance = ChatAppOrm()
    instance.create_tables()
    instance.delete_user("Alon")
    #instance.insert_user((user1.name,user1.password,user1.bio,user1.createdDate))
    #instance.update_user((user1.name,"Alon",user1.password,user1.bio,user1.createdDate))