import socket

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect(("127.0.0.1",55))

def send_message(message):
    # Send the message to the server
    client_socket.send(message.encode('utf-8'))
def recive_message():
    message = client_socket.recv(1024).decode('utf-8')
    return message
def login(username,password):
    send_message("login~" + username + "~" + str(password))
    returnedMessage = recive_message()
    #print(returnedMessage) Not coming to here
    return returnedMessage
def sign_up(name,password,bio,createdDate):
    send_message("signup~" + name + "~" + str(password) + "~" + bio + "~" + createdDate) 
    return recive_message()
if __name__ == "__main__":
    print(sign_up("GuyYY",1234, "Hello World", "10/10/10"))    
    print(login("GuyYY",1234))
