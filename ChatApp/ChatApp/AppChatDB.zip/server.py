import socket
import threading
import DBManager
instance = DBManager.ChatAppOrm()
def send_message(client_socket, message):
    client_socket.send(message.encode("utf-8"))

def checkLogin(username,password):
    print("Checking the login information")
    for user in instance.get_all_users():
        if user.name == username and user.password == password:
            return "Login was succesful"
    return "Login Failed"

def checkSignUp(name,password,bio,createdDate):
    print("Checking the login information")

    returnedValue = instance.insert_user((name,password,bio,createdDate))
    if(returnedValue[0]):
        return "User Was Added Succesfuly"
    else:
        return returnedValue[1]
def handle_client(client_socket):
    # Handle messages from a client
    try:
        while True:
            message = client_socket.recv(1024).decode()
            if not message:
                break
            message = message.split("~")
            print(message)
            if message[0] == "login":
                result = checkLogin(message[1],message[2])
                send_message(client_socket,result)
            elif message[0] == "signup":
                result = checkSignUp(message[1],message[2],message[3],message[4])
                send_message(client_socket,result)

    except Exception as e:
        print(f"Error handling client: {e}")


if __name__ == "__main__":
    server_socket = socket.socket()
    server_socket.bind(("127.0.0.1",55))
    server_socket.listen()
    clients = []
    while True:
        client_socket, addr = server_socket.accept()
        clients.append(client_socket)
        client_thread = threading.Thread(target=handle_client, args=(client_socket,))
        client_thread.start()

    